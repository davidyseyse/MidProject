package tw.xiaoyuan.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import tw.xiaoyuan.javabean.Campaign;

public class DaoCampaign {
	private Connection conn;
	
	public boolean createConnection() throws NamingException, SQLException {
		InitialContext context = new InitialContext();
		DataSource ds = (DataSource)context.lookup("java:comp/env/connSQLServerJndi/OrderService");		
		conn = ds.getConnection();
		if (!conn.isClosed()){
			return true;
		}
		return false;
	}
	
	public void insert(Campaign camp) throws SQLException {
		String sqlstr = "insert into campaign(Ttile,decription,startTime,endTime,type,status)"
				+ "values(?,?,?,?,?,?)";
		PreparedStatement state = conn.prepareStatement(sqlstr);
		state.setString(1,camp.getTitle());
		state.setString(2,camp.getDescription());
		state.setTimestamp(3, camp.getStartTime());
		state.setTimestamp(4, camp.getEndTime());
		state.setInt(5,camp.getType());
		state.setBoolean(6,camp.getStatus());
		state.execute();
	}
	
	public ArrayList<Campaign> queryAll() throws SQLException {
		ArrayList<Campaign> list = new ArrayList<Campaign>();
		String sqlstr = "select * from campaign";
		PreparedStatement state = conn.prepareStatement(sqlstr);
		ResultSet res = state.executeQuery();

		while(res.next()) {
			String title = res.getString(1);
			String description = res.getString(2);
			Timestamp startTime = res.getTimestamp(3);
			Timestamp endTime = res.getTimestamp(4);
			int type = res.getInt(5);
			int id = res.getInt(6);
			boolean status = res.getBoolean(7);
			Campaign camp = new Campaign(id,title,description,startTime,endTime,status);
			list.add(camp);	
		}
		
		return list;
	}
	
	public void close() throws SQLException {
		if(conn!=null) {
			conn.close();
		}
	}
	
}
