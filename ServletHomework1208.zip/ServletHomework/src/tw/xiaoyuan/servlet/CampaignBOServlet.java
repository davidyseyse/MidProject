package tw.xiaoyuan.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.sql.Timestamp;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.xiaoyuan.javabean.Campaign;
import tw.xiaoyuan.jdbc.DaoCampaign;


@WebServlet("/CampaignBOServlet")
public class CampaignBOServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		
		String title = request.getParameter("title");
		
		String startDate = request.getParameter("startDate");
		String startTime = request.getParameter("startTime");
		String StartDateTime = startDate+" "+startTime+":00";
		Timestamp StartDateTimeStamp = Timestamp.valueOf(StartDateTime);
		
		String endDate = request.getParameter("endDate");
		String endTime = request.getParameter("endTime");
		String endDateTime = endDate+" "+endTime+":00";
		Timestamp endDateTimeStamp = Timestamp.valueOf(endDateTime);
		
		Boolean status = Boolean.valueOf(request.getParameter("status"));	
		String description = request.getParameter("description");
				

		Campaign camp =  new Campaign(title,description,StartDateTimeStamp,endDateTimeStamp,status);
		request.setAttribute("camp", camp);
		
		DaoCampaign dao = new DaoCampaign();
		try {
			dao.createConnection();
			dao.insert(camp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				dao.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		RequestDispatcher dis = request.getRequestDispatcher("showResult.jsp");
		dis.forward(request, response);
	}

}
