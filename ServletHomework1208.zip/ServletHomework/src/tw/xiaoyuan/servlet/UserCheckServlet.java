package tw.xiaoyuan.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.xiaoyuan.javabean.User;
import tw.xiaoyuan.jdbc.DaoUser;


@WebServlet("/UserCheckServlet")
public class UserCheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processAciton(request,response);
	}


	private void processAciton(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session = request.getSession();
		String userId = request.getParameter("userId");
		String userPassword = request.getParameter("userPassword");
		System.out.println(userId);
		System.out.println(userPassword);
		User user = null;
		DaoUser dao = new DaoUser();
		try {
			dao.createConnection();
			user = dao.queryUser(userId, userPassword);
			if (user!=null) {
				session.setAttribute("isMember", true);
				session.setAttribute("member", user);
			}else {
				session.setAttribute("isMember", false);
				session.setAttribute("member", null);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				dao.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println(user);
		try {
			if(user!=null) {
				response.sendRedirect("LoginSuccess.jsp");
			}			
			else {
				response.sendRedirect("LoginErrorPage.jsp");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
